let tasks = [];

function addTask() {
  const taskName = document.getElementById("taskName").value;
  const taskDate = document.getElementById("taskDate").value;
  const taskTime = document.getElementById("taskTime").value;
  
  if (!taskName || !taskDate || !taskTime) {
    alert("Please fill in all fields.");
    return;
  }

  const task = {
    name: taskName,
    date: taskDate,
    time: taskTime,
    status: "none", // "none", "true" (completed), or "false" (scheduled)
  };

  tasks.push(task);
  renderTasks();
}

function renderTasks(filter = null) {
  const tableBody = document.getElementById("taskTable").getElementsByTagName("tbody")[0];
  tableBody.innerHTML = '';

  const filteredTasks = filter ? tasks.filter(task => task.status === filter) : tasks;

  filteredTasks.forEach((task, index) => {
    const row = tableBody.insertRow();
    row.innerHTML = `
      <td>${task.name}</td>
      <td>${task.date} ${task.time}</td>
      <td>${task.status === "none" ? "Ongoing" : task.status === "true" ? "Completed" : "Scheduled"}</td>
      <td>
        <button onclick="updateTaskStatus(${index})" class="update">Update Status</button>
        <button onclick="deleteTask(${index})" class="delete">Delete</button>
      </td>
    `;
  });
}

function updateTaskStatus(index) {
  const task = tasks[index];
  
  if (task.status === "none") {
    task.status = "false"; // change to scheduled
  } else if (task.status === "false") {
    task.status = "true"; // change to completed
  } else {
    task.status = "none"; // change back to ongoing
  }

  renderTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  renderTasks();
}

function filterTasks(status) {
  renderTasks(status);
}

function clearTasks() {
  tasks = [];
  renderTasks();
}
